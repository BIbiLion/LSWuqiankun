#ifndef __CLIENTCENTER_H_INCLUDED
#define __CLIENTCENTER_H_INCLUDED

#include "IClientCenter.h"

class CClientCenter : public IClientCenter
{

};

#endif