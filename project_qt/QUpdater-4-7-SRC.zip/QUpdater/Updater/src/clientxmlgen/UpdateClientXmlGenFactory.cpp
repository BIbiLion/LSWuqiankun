#include "stdafx.h"
#include "IUpdateClientXmlGenFactory.h"