#ifndef __IUPDATECLIENTXMLGENFACTORY_H_INCLUDED
#define __IUPDATECLIENTXMLGENFACTORY_H_INCLUDED

#ifndef _USRDLL
#define DLLDX __declspec(dllimport)
#else
#define DLLDX __declspec(dllexport)
#endif

struct IUpdateClientXmlGenFactory 
{
	
};

//IUpdateClientXmlGenFactory* DLLDX funcUpdateClientXmlGenFactory();

#endif