#ifndef __FUNCDEFIN_H_INCLUDED
#define __FUNCDEFIN_H_INCLUDED

#include "../../../include/MBCSUNICODESTD.h"

typedef bool (*TFunStr)(const MUString&);
typedef bool (*TFunVoid)();


const MUString funcstr [] = {
	_T("validateUpdaterClientXmlFile"),
	_T("appendSoft"),
	_T("removeSoftFromUpdaterClientXmlFile"),
	_T("removePackFromUpdaterClientXmlFile"),
	_T("loadUpdaterClientXmlFile"),
	_T("saveUpdaterClientXmlFile"),
	_T("repairUpdaterClientXmlFile"),
	_T("removeSoft")
};

#endif