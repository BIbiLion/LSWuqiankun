#include "task.h"

task::task(QDir dir)
{
    qDebug() << "task";
    saveDir=dir;
    this->downloaded=0;
    this->total=1;
    taskTime=new QTime(QTime::currentTime());
}

void task::run()
{
    qDebug() << "run14";
    return;
}
void task::doDownload()
{
    qDebug() << "doDownload19";
    return;
}
void task::downloadProgress(int done, int total)
{

    qDebug() << "downloadProgress25";
}
void task::downloadFinished(bool error)
{

    qDebug() << "downloadFinished30";
}
bool task::startTask()
{
    qDebug() << "startTask34";
    return true;
}

bool task::pauseTask()
{
    qDebug() << "pauseTask40";
    return true;
}


