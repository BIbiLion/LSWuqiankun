#ifndef HTTPTASK_H
#define HTTPTASK_H
#include "task.h"
#include <QUrl>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkAccessManager>
#include <QFile>
#include <QEventLoop>
#include "httpthread.h"
#include "QMutex"
#include "QList"

#include "QMessageBox"

#include <qthread.h>

class HttpTask : public task
{
    Q_OBJECT
public:
    HttpTask(QUrl u,QDir d,short threadCount);
    QUrl getUrl();
    virtual void run();
    virtual void doDownload(QUrl fileURL);
private:
    short threadCount;
    short threaddonecount;
    QList<HttpThread *> ThreadList;
    QMutex mutex;
public slots:
    virtual void progressChanged(long done);
    virtual bool startTask();
    virtual bool pauseTask();
    virtual void downloadFinished(bool flag);
    void threadfinished(bool flag);
//    void getheader(QHttpResponseHeader fileHeader);
};

#endif // HTTPTASK_H
