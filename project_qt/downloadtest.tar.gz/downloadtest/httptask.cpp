#include "httptask.h"
#include "QDebug"

HttpTask::HttpTask(QUrl u,QDir d,short threadCount)
  :task(d)
{
    qDebug() << "HttpTask";
    this->url=u;
    QString path = url.path();
    QString name = QFileInfo(path).fileName();

    this->threadCount=threadCount;
    this->state=READY;
    this->taskName=name;
    this->threaddonecount=0;

    QDir::setCurrent(saveDir.path());
    file = new QFile(QFileInfo(url.path()).fileName());
    file->open(QIODevice::ReadWrite);
}
void HttpTask::run()
{
    qDebug() << "run23";
    taskTime->start();
    this->doDownload(url);
    exec();
}
void HttpTask::doDownload(QUrl fileURL)
{
    qDebug() << "doDownload30";
    total = -1;
    QNetworkAccessManager * ma = new QNetworkAccessManager;
    QNetworkRequest headReq(fileURL);
    //qDebug()<<"获取下载文件的大小......";
    headReq.setRawHeader("User-Agent", "");  //Content-Length

    QNetworkReply*  headReply = NULL;
    bool connectError = false;
    int tryTimes = 1;
    //如果失败,连接尝试3次;
    do{
//        qDebug()<<"正在进行"<<4 - tryTimes<<"次连接尝试...";
        connectError = false;
        headReply =  ma->head(headReq);
        if(!headReply)
          {
            connectError = true;
            continue;
          }
        QEventLoop loop;
        connect(headReply, SIGNAL(finished()), &loop, SLOT(quit()));
        loop.exec();
        connectError = (headReply->error() != QNetworkReply::NoError);
//        if(connectError)
//            qDebug()<<"连接失败!";
        headReply->deleteLater();
      } while (connectError && --tryTimes);

//    qDebug() << headReply << "headReply^^^^^^^^^^^^^^^^^^^^^^^^^^";
    int statusCode = headReply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();

    if(statusCode == 302)
    {
        QUrl newUrl = headReply->header(QNetworkRequest::LocationHeader).toUrl();
        if(newUrl.isValid())
          {
//            qDebug()<<"重定向："<<newUrl;
            fileURL = newUrl.toString();
            return doDownload(fileURL);
          }
    }
    else
    {
        total = headReply->header(QNetworkRequest::ContentLengthHeader).toLongLong();

        long begin = 0;
        long step =0;
        if(0==total/threadCount)
            step=total/threadCount;
        else
            step = (long)(total / (threadCount-1));
        begin=-step;
        qlonglong end = 0;
        for (short ThreadIndex = 1; ThreadIndex <= threadCount; ThreadIndex++)
        {
              end += step;
              qDebug() << "end::::::::::::::::::::::::::::::::::::"<< end;
              begin +=step;
              if (end > total)
              {
                  end = total+1;
              }
              HttpThread *thread=new HttpThread(ThreadIndex,begin,end-1,url,file);
              ThreadList.append(thread);
              connect(thread,SIGNAL(progressChanged(long)),
                      this,SLOT(progressChanged(long)));

              connect(thread,SIGNAL(finish(bool)),this,SLOT(threadfinished(bool)));
              ThreadList.at(ThreadIndex-1)->start();
        }
    }

    headReply->deleteLater();
    ma->deleteLater();
}
void HttpTask::downloadFinished(bool error)
{
    qDebug() << "downloadFinished";
    file->close();
    QMessageBox m;
    m.setText(this->file->fileName());
    m.exec();
    this->quit();
}
bool HttpTask::startTask()
{
    qDebug() << "startTask113";
    return true;
}
bool HttpTask::pauseTask()
{
    qDebug() << "pauseTask118";
    return true;
}
//void HttpTask::getheader(QHttpResponseHeader fileHeader)
//{
////  qDebug()<<"getheader";
////    total=fileHeader.value("Content-Length").toLong();
////    qDebug()<<total / 1024;
////    long begin = 0;
////    long step =0;
////    if(0==total/threadCount)
////        step=this->total/threadCount;
////    else
////        step = (long)(total / (threadCount-1));
////    begin=-step;
////    long end = 0;
////    for (short ThreadIndex = 1; ThreadIndex <= threadCount; ThreadIndex++)
////    {
////          end += step;
////          begin +=step;
////          if (end >= total)
////                end = total;
////          HttpThread *thread=new HttpThread(ThreadIndex,begin,end-1,url,file);
////          ThreadList.append(thread);
////          connect(thread,SIGNAL(progressChanged(long)),
////                  this,SLOT(progressChanged(long)));

////          connect(thread,SIGNAL(finish(bool)),this,SLOT(threadfinished(bool)));
////          ThreadList.at(ThreadIndex-1)->start();
////    }
//}

void HttpTask::progressChanged(long done)
{
    mutex.lock();
    downloaded+=done;
    mutex.unlock();
}
void HttpTask::threadfinished(bool flag)
{
    qDebug() << "threadfinished$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$";
    if(flag)
        this->threaddonecount++;
    if(this->threadCount==this->threaddonecount)
    {
        this->downloadFinished(flag);
    }
}

QUrl HttpTask::getUrl()
{
    qDebug() << "getUrl166";
    return url;
}
