/****************************************************************************
** Meta object code from reading C++ file 'qbattery.h'
**
** Created: Sun Jan 2 15:39:01 2011
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/qbattery.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qbattery.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QBattery[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      16,   10,    9,    9, 0x05,

 // slots: signature, parameters, type, tag, flags
      36,   10,    9,    9, 0x0a,
      52,    9,    9,    9, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_QBattery[] = {
    "QBattery\0\0value\0valueChanged(qreal)\0"
    "setValue(qreal)\0UpdateGraph()\0"
};

const QMetaObject QBattery::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QBattery,
      qt_meta_data_QBattery, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QBattery::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QBattery::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QBattery::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QBattery))
        return static_cast<void*>(const_cast< QBattery*>(this));
    return QWidget::qt_metacast(_clname);
}

int QBattery::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: valueChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 1: setValue((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 2: UpdateGraph(); break;
        default: ;
        }
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void QBattery::valueChanged(qreal _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
