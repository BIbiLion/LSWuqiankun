#ifndef __QT_ALL_INCLUDES__
#define __QT_ALL_INCLUDES__

#include <QMainWindow>
#include <QWidget>
#include <QTimer>
#include <QCursor>
#include <QPainter>
#include <QMouseEvent>
#include <QWidget>
#include <QPixmap>
#include <QDesktopWidget>
#include <QApplication>
#include <Windows.h>

#endif