/****************************************************************************
** Meta object code from reading C++ file 'myserialport.h'
**
** Created: Sat Nov 15 23:02:42 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.4.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../myserialport.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'myserialport.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.4.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MySerialPort[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x08,
      60,   13,   13,   13, 0x08,
     112,   13,   13,   13, 0x08,
     162,   13,   13,   13, 0x08,
     212,   13,   13,   13, 0x08,
     260,   13,   13,   13, 0x08,
     310,   13,   13,   13, 0x08,
     339,   13,   13,   13, 0x08,
     373,   13,   13,   13, 0x08,
     406,   13,   13,   13, 0x08,
     435,   13,   13,   13, 0x08,
     471,   13,   13,   13, 0x08,
     502,   13,   13,   13, 0x08,
     532,   13,   13,   13, 0x08,
     571,   13,   13,   13, 0x08,
     610,   13,   13,   13, 0x08,
     632,   13,   13,   13, 0x08,
     649,  642,   13,   13, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MySerialPort[] = {
    "MySerialPort\0\0"
    "on_comboBox_Comm_currentIndexChanged(QString)\0"
    "on_comboBox_DisplayRec_currentIndexChanged(QString)\0"
    "on_comboBox_StopBits_currentIndexChanged(QString)\0"
    "on_comboBox_DataBits_currentIndexChanged(QString)\0"
    "on_comboBox_Parity_currentIndexChanged(QString)\0"
    "on_comboBox_BaudRate_currentIndexChanged(QString)\0"
    "on_pushButton_Send_clicked()\0"
    "on_pushButton_ClearSend_clicked()\0"
    "on_pushButton_ClearRec_clicked()\0"
    "on_pushButton_Open_clicked()\0"
    "on_pushButton_StopDisplay_clicked()\0"
    "on_pushButton_Browse_clicked()\0"
    "on_pushButton_About_clicked()\0"
    "on_checkBox_AutoSend_stateChanged(int)\0"
    "on_lineEdit_SendTime_editingFinished()\0"
    "updateReceiveWindow()\0timeout()\0action\0"
    "onScroll(int)\0"
};

const QMetaObject MySerialPort::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_MySerialPort,
      qt_meta_data_MySerialPort, 0 }
};

const QMetaObject *MySerialPort::metaObject() const
{
    return &staticMetaObject;
}

void *MySerialPort::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MySerialPort))
        return static_cast<void*>(const_cast< MySerialPort*>(this));
    return QDialog::qt_metacast(_clname);
}

int MySerialPort::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_comboBox_Comm_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: on_comboBox_DisplayRec_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: on_comboBox_StopBits_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: on_comboBox_DataBits_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: on_comboBox_Parity_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: on_comboBox_BaudRate_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: on_pushButton_Send_clicked(); break;
        case 7: on_pushButton_ClearSend_clicked(); break;
        case 8: on_pushButton_ClearRec_clicked(); break;
        case 9: on_pushButton_Open_clicked(); break;
        case 10: on_pushButton_StopDisplay_clicked(); break;
        case 11: on_pushButton_Browse_clicked(); break;
        case 12: on_pushButton_About_clicked(); break;
        case 13: on_checkBox_AutoSend_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: on_lineEdit_SendTime_editingFinished(); break;
        case 15: updateReceiveWindow(); break;
        case 16: timeout(); break;
        case 17: onScroll((*reinterpret_cast< int(*)>(_a[1]))); break;
        }
        _id -= 18;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
