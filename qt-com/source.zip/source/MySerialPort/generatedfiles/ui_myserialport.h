/********************************************************************************
** Form generated from reading ui file 'myserialport.ui'
**
** Created: Sat Nov 15 23:02:42 2008
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MYSERIALPORT_H
#define UI_MYSERIALPORT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QLCDNumber>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MySerialPortClass
{
public:
    QGroupBox *groupBox_SerialPort;
    QGridLayout *gridLayout;
    QComboBox *comboBox_Comm;
    QComboBox *comboBox_BaudRate;
    QComboBox *comboBox_Parity;
    QComboBox *comboBox_DataBits;
    QLabel *label_5;
    QComboBox *comboBox_StopBits;
    QPushButton *pushButton_Open;
    QLabel *label_4;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label;
    QGroupBox *groupBox_SendBuf;
    QTextEdit *textEdit_Send;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_3;
    QComboBox *comboBox_DisplaySend;
    QLCDNumber *lcdNumber_SendBytes;
    QLineEdit *lineEdit_SendTime;
    QCheckBox *checkBox_AutoSend;
    QPushButton *pushButton_ClearSend;
    QPushButton *pushButton_Send;
    QPushButton *pushButton_Browse;
    QPushButton *pushButton_About;
    QGroupBox *groupBox_RecBuf;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_ClearRec;
    QPushButton *pushButton_StopDisplay;
    QComboBox *comboBox_DisplayRec;
    QCheckBox *checkBox_AutoClear;
    QLCDNumber *lcdNumber_ReceivedBytes;
    QPlainTextEdit *plainTextEdit_RecBuf;

    void setupUi(QDialog *MySerialPortClass)
    {
    if (MySerialPortClass->objectName().isEmpty())
        MySerialPortClass->setObjectName(QString::fromUtf8("MySerialPortClass"));
    MySerialPortClass->resize(677, 514);
    QIcon icon;
    icon.addPixmap(QPixmap(QString::fromUtf8(":/MySerialPort/Resources/icon_big.bmp")), QIcon::Normal, QIcon::Off);
    MySerialPortClass->setWindowIcon(icon);
    groupBox_SerialPort = new QGroupBox(MySerialPortClass);
    groupBox_SerialPort->setObjectName(QString::fromUtf8("groupBox_SerialPort"));
    groupBox_SerialPort->setGeometry(QRect(10, 10, 151, 204));
    gridLayout = new QGridLayout(groupBox_SerialPort);
    gridLayout->setSpacing(6);
    gridLayout->setMargin(11);
    gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
    comboBox_Comm = new QComboBox(groupBox_SerialPort);
    comboBox_Comm->setObjectName(QString::fromUtf8("comboBox_Comm"));

    gridLayout->addWidget(comboBox_Comm, 0, 1, 1, 1);

    comboBox_BaudRate = new QComboBox(groupBox_SerialPort);
    comboBox_BaudRate->setObjectName(QString::fromUtf8("comboBox_BaudRate"));

    gridLayout->addWidget(comboBox_BaudRate, 1, 1, 2, 1);

    comboBox_Parity = new QComboBox(groupBox_SerialPort);
    comboBox_Parity->setObjectName(QString::fromUtf8("comboBox_Parity"));

    gridLayout->addWidget(comboBox_Parity, 3, 1, 2, 1);

    comboBox_DataBits = new QComboBox(groupBox_SerialPort);
    comboBox_DataBits->setObjectName(QString::fromUtf8("comboBox_DataBits"));

    gridLayout->addWidget(comboBox_DataBits, 5, 1, 2, 1);

    label_5 = new QLabel(groupBox_SerialPort);
    label_5->setObjectName(QString::fromUtf8("label_5"));

    gridLayout->addWidget(label_5, 7, 0, 1, 1);

    comboBox_StopBits = new QComboBox(groupBox_SerialPort);
    comboBox_StopBits->setObjectName(QString::fromUtf8("comboBox_StopBits"));

    gridLayout->addWidget(comboBox_StopBits, 7, 1, 1, 1);

    pushButton_Open = new QPushButton(groupBox_SerialPort);
    pushButton_Open->setObjectName(QString::fromUtf8("pushButton_Open"));

    gridLayout->addWidget(pushButton_Open, 8, 0, 1, 2);

    label_4 = new QLabel(groupBox_SerialPort);
    label_4->setObjectName(QString::fromUtf8("label_4"));

    gridLayout->addWidget(label_4, 6, 0, 1, 1);

    label_3 = new QLabel(groupBox_SerialPort);
    label_3->setObjectName(QString::fromUtf8("label_3"));

    gridLayout->addWidget(label_3, 4, 0, 1, 1);

    label_2 = new QLabel(groupBox_SerialPort);
    label_2->setObjectName(QString::fromUtf8("label_2"));

    gridLayout->addWidget(label_2, 2, 0, 1, 1);

    label = new QLabel(groupBox_SerialPort);
    label->setObjectName(QString::fromUtf8("label"));

    gridLayout->addWidget(label, 0, 0, 1, 1);

    groupBox_SendBuf = new QGroupBox(MySerialPortClass);
    groupBox_SendBuf->setObjectName(QString::fromUtf8("groupBox_SendBuf"));
    groupBox_SendBuf->setGeometry(QRect(10, 350, 661, 151));
    textEdit_Send = new QTextEdit(groupBox_SendBuf);
    textEdit_Send->setObjectName(QString::fromUtf8("textEdit_Send"));
    textEdit_Send->setGeometry(QRect(160, 20, 491, 121));
    layoutWidget = new QWidget(groupBox_SendBuf);
    layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
    layoutWidget->setGeometry(QRect(10, 20, 131, 117));
    gridLayout_3 = new QGridLayout(layoutWidget);
    gridLayout_3->setSpacing(6);
    gridLayout_3->setMargin(11);
    gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
    gridLayout_3->setContentsMargins(0, 0, 0, 0);
    comboBox_DisplaySend = new QComboBox(layoutWidget);
    comboBox_DisplaySend->setObjectName(QString::fromUtf8("comboBox_DisplaySend"));

    gridLayout_3->addWidget(comboBox_DisplaySend, 0, 0, 1, 1);

    lcdNumber_SendBytes = new QLCDNumber(layoutWidget);
    lcdNumber_SendBytes->setObjectName(QString::fromUtf8("lcdNumber_SendBytes"));
    QPalette palette;
    QBrush brush(QColor(255, 255, 255, 255));
    brush.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
    QBrush brush1(QColor(0, 0, 0, 255));
    brush1.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Active, QPalette::Button, brush1);
    palette.setBrush(QPalette::Active, QPalette::Light, brush1);
    palette.setBrush(QPalette::Active, QPalette::Midlight, brush1);
    palette.setBrush(QPalette::Active, QPalette::Dark, brush1);
    palette.setBrush(QPalette::Active, QPalette::Mid, brush1);
    palette.setBrush(QPalette::Active, QPalette::Text, brush);
    palette.setBrush(QPalette::Active, QPalette::BrightText, brush);
    palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
    palette.setBrush(QPalette::Active, QPalette::Base, brush1);
    palette.setBrush(QPalette::Active, QPalette::Window, brush1);
    palette.setBrush(QPalette::Active, QPalette::Shadow, brush1);
    palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
    QBrush brush2(QColor(255, 255, 220, 255));
    brush2.setStyle(Qt::SolidPattern);
    palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush2);
    palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
    palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Light, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Mid, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
    palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush);
    palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
    palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
    palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush2);
    palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Light, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Mid, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Text, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush);
    palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
    palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush2);
    palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush1);
    lcdNumber_SendBytes->setPalette(palette);
    lcdNumber_SendBytes->setSegmentStyle(QLCDNumber::Filled);

    gridLayout_3->addWidget(lcdNumber_SendBytes, 0, 1, 1, 1);

    lineEdit_SendTime = new QLineEdit(layoutWidget);
    lineEdit_SendTime->setObjectName(QString::fromUtf8("lineEdit_SendTime"));
    lineEdit_SendTime->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

    gridLayout_3->addWidget(lineEdit_SendTime, 1, 0, 1, 1);

    checkBox_AutoSend = new QCheckBox(layoutWidget);
    checkBox_AutoSend->setObjectName(QString::fromUtf8("checkBox_AutoSend"));

    gridLayout_3->addWidget(checkBox_AutoSend, 1, 1, 1, 1);

    pushButton_ClearSend = new QPushButton(layoutWidget);
    pushButton_ClearSend->setObjectName(QString::fromUtf8("pushButton_ClearSend"));

    gridLayout_3->addWidget(pushButton_ClearSend, 2, 0, 1, 1);

    pushButton_Send = new QPushButton(layoutWidget);
    pushButton_Send->setObjectName(QString::fromUtf8("pushButton_Send"));

    gridLayout_3->addWidget(pushButton_Send, 2, 1, 1, 1);

    pushButton_Browse = new QPushButton(layoutWidget);
    pushButton_Browse->setObjectName(QString::fromUtf8("pushButton_Browse"));

    gridLayout_3->addWidget(pushButton_Browse, 3, 0, 1, 1);

    pushButton_About = new QPushButton(layoutWidget);
    pushButton_About->setObjectName(QString::fromUtf8("pushButton_About"));

    gridLayout_3->addWidget(pushButton_About, 3, 1, 1, 1);

    layoutWidget->raise();
    textEdit_Send->raise();
    groupBox_RecBuf = new QGroupBox(MySerialPortClass);
    groupBox_RecBuf->setObjectName(QString::fromUtf8("groupBox_RecBuf"));
    groupBox_RecBuf->setGeometry(QRect(10, 220, 151, 115));
    gridLayout_2 = new QGridLayout(groupBox_RecBuf);
    gridLayout_2->setSpacing(6);
    gridLayout_2->setMargin(11);
    gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
    pushButton_ClearRec = new QPushButton(groupBox_RecBuf);
    pushButton_ClearRec->setObjectName(QString::fromUtf8("pushButton_ClearRec"));

    gridLayout_2->addWidget(pushButton_ClearRec, 2, 0, 1, 1);

    pushButton_StopDisplay = new QPushButton(groupBox_RecBuf);
    pushButton_StopDisplay->setObjectName(QString::fromUtf8("pushButton_StopDisplay"));

    gridLayout_2->addWidget(pushButton_StopDisplay, 2, 1, 1, 1);

    comboBox_DisplayRec = new QComboBox(groupBox_RecBuf);
    comboBox_DisplayRec->setObjectName(QString::fromUtf8("comboBox_DisplayRec"));

    gridLayout_2->addWidget(comboBox_DisplayRec, 4, 0, 1, 1);

    checkBox_AutoClear = new QCheckBox(groupBox_RecBuf);
    checkBox_AutoClear->setObjectName(QString::fromUtf8("checkBox_AutoClear"));
    checkBox_AutoClear->setEnabled(false);

    gridLayout_2->addWidget(checkBox_AutoClear, 0, 0, 1, 2);

    lcdNumber_ReceivedBytes = new QLCDNumber(groupBox_RecBuf);
    lcdNumber_ReceivedBytes->setObjectName(QString::fromUtf8("lcdNumber_ReceivedBytes"));
    QPalette palette1;
    palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
    palette1.setBrush(QPalette::Active, QPalette::Button, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Light, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Midlight, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Dark, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Mid, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Text, brush);
    palette1.setBrush(QPalette::Active, QPalette::BrightText, brush);
    palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush);
    palette1.setBrush(QPalette::Active, QPalette::Base, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Window, brush1);
    palette1.setBrush(QPalette::Active, QPalette::Shadow, brush1);
    palette1.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
    palette1.setBrush(QPalette::Active, QPalette::ToolTipBase, brush2);
    palette1.setBrush(QPalette::Active, QPalette::ToolTipText, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
    palette1.setBrush(QPalette::Inactive, QPalette::Button, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Light, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Midlight, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Mid, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
    palette1.setBrush(QPalette::Inactive, QPalette::BrightText, brush);
    palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
    palette1.setBrush(QPalette::Inactive, QPalette::Base, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Window, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::Shadow, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
    palette1.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush2);
    palette1.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Button, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Light, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Mid, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Text, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::BrightText, brush);
    palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Base, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Window, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::Shadow, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
    palette1.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush2);
    palette1.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush1);
    lcdNumber_ReceivedBytes->setPalette(palette1);

    gridLayout_2->addWidget(lcdNumber_ReceivedBytes, 4, 1, 1, 1);

    plainTextEdit_RecBuf = new QPlainTextEdit(MySerialPortClass);
    plainTextEdit_RecBuf->setObjectName(QString::fromUtf8("plainTextEdit_RecBuf"));
    plainTextEdit_RecBuf->setGeometry(QRect(170, 10, 491, 331));
    plainTextEdit_RecBuf->setAcceptDrops(false);
    plainTextEdit_RecBuf->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    plainTextEdit_RecBuf->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    plainTextEdit_RecBuf->setUndoRedoEnabled(false);

    retranslateUi(MySerialPortClass);

    QMetaObject::connectSlotsByName(MySerialPortClass);
    } // setupUi

    void retranslateUi(QDialog *MySerialPortClass)
    {
    groupBox_SerialPort->setTitle(QApplication::translate("MySerialPortClass", "\344\270\262\345\217\243\350\256\276\347\275\256", 0, QApplication::UnicodeUTF8));
    label_5->setText(QApplication::translate("MySerialPortClass", "\345\201\234\346\255\242\344\275\215", 0, QApplication::UnicodeUTF8));
    pushButton_Open->setText(QApplication::translate("MySerialPortClass", "\346\211\223\345\274\200\344\270\262\345\217\243(&O)", 0, QApplication::UnicodeUTF8));
    label_4->setText(QApplication::translate("MySerialPortClass", "\346\225\260\346\215\256\344\275\215", 0, QApplication::UnicodeUTF8));
    label_3->setText(QApplication::translate("MySerialPortClass", "\346\240\241\351\252\214\344\275\215", 0, QApplication::UnicodeUTF8));
    label_2->setText(QApplication::translate("MySerialPortClass", "\346\263\242\347\211\271\347\216\207", 0, QApplication::UnicodeUTF8));
    label->setText(QApplication::translate("MySerialPortClass", "\344\270\262\345\217\243\345\217\267", 0, QApplication::UnicodeUTF8));
    groupBox_SendBuf->setTitle(QApplication::translate("MySerialPortClass", "\345\217\221\351\200\201\347\274\223\345\206\262\345\214\272", 0, QApplication::UnicodeUTF8));

#ifndef QT_NO_TOOLTIP
    lineEdit_SendTime->setToolTip(QApplication::translate("MySerialPortClass", "\350\207\252\345\212\250\345\217\221\351\200\201\351\227\264\351\232\224\357\274\214\345\215\225\344\275\215\357\274\232\346\257\253\347\247\222", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP

    lineEdit_SendTime->setText(QApplication::translate("MySerialPortClass", "1000", 0, QApplication::UnicodeUTF8));
    checkBox_AutoSend->setText(QApplication::translate("MySerialPortClass", "\350\207\252\345\212\250", 0, QApplication::UnicodeUTF8));
    pushButton_ClearSend->setText(QApplication::translate("MySerialPortClass", "\346\270\205\347\251\272(L)", 0, QApplication::UnicodeUTF8));
    pushButton_Send->setText(QApplication::translate("MySerialPortClass", "\345\217\221\351\200\201(D)", 0, QApplication::UnicodeUTF8));
    pushButton_Browse->setText(QApplication::translate("MySerialPortClass", "\351\200\200\345\207\272(&E)", 0, QApplication::UnicodeUTF8));
    pushButton_About->setText(QApplication::translate("MySerialPortClass", "\345\205\263\344\272\216(&A)", 0, QApplication::UnicodeUTF8));
    groupBox_RecBuf->setTitle(QApplication::translate("MySerialPortClass", "\346\216\245\346\224\266\347\274\223\345\206\262\345\214\272", 0, QApplication::UnicodeUTF8));
    pushButton_ClearRec->setText(QApplication::translate("MySerialPortClass", "\346\270\205\347\251\272(&C)", 0, QApplication::UnicodeUTF8));
    pushButton_StopDisplay->setText(QApplication::translate("MySerialPortClass", "\345\201\234\346\255\242(&S)", 0, QApplication::UnicodeUTF8));
    checkBox_AutoClear->setText(QApplication::translate("MySerialPortClass", "\350\207\252\345\212\250\346\270\205\347\251\272(&A)", 0, QApplication::UnicodeUTF8));

#ifndef QT_NO_TOOLTIP
    lcdNumber_ReceivedBytes->setToolTip(QApplication::translate("MySerialPortClass", "\345\267\262\345\217\221\351\200\201\345\255\227\350\212\202", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP

    Q_UNUSED(MySerialPortClass);
    } // retranslateUi

};

namespace Ui {
    class MySerialPortClass: public Ui_MySerialPortClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYSERIALPORT_H
